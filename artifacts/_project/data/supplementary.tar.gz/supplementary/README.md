# Supplementary Archive

## Contents

| Category | File count |
|---|---:|
| `code/` | 6 |
| `data/` | 54 |
| `generators/` | 4 |
| `latex/` | 23 |
| Total archived files, including this README | 88 |

## Reproduction Requirements

- Python 3.12 or later.
- Standard-library Python plus PyYAML for the archive builder.
- LaTeX tooling is required only to rebuild the paper PDF from `latex/`.
- Artifact payload membership is resolved from `artifacts/manifest.yaml` and verified by SHA-256 before packaging.

## Server-Only Payloads

No payload is copied directly from a server-only path by this archive builder. All included payloads are resolved from the project artifact manifest.

## Provenance Metadata

Some artifacts in this archive are provenance records written by the tools that produced them. Those records include local execution paths and environment details of the machine that ran the analysis, such as a project directory name, a container path, a Python environment path, and, in two analysis files, a private cloud hostname and region string recorded by a non-canonical analysis run. The artifacts are shipped byte-identical and unedited so that the content hashes printed in the paper remain valid. The recorded paths are provenance metadata, not results.

## Cited Artifact Provenance

| Artifact id | Filename | SHA-256 |
|---|---|---|
| `art_20260913_e5ebac` | `q1_lower_side_full_n.json` | `9fe81e271a386335a9526563ca03631bcdf832fa5d66d3861b2e22ec079256f5` |
| `art_20260914_443901` | `x1_headline_table.json` | `c9f840a94644687e50e672f6cdd3c65fd0469a9045ca55d1881d11a8afd41c9c` |
| `art_20260915_27333a` | `ci_main_table.json` | `2d87922190e21f06fbd7e47ebe62f22f494c45252d84578c3ff9f888176b2c86` |
| `art_20260918_17c1b0` | `coverage_calibration_ladder.json` | `86bd86a27a6efe8edacfbe5cafd2b38c5b4724e5f95de8f9afa5355e3c43d29a` |
| `art_20260918_4b3dc7` | `coverage_calibration_v2.md` | `7cb28ef9022730d21b99545fb39126dcd7c957fd9cd873333bca244e28273e08` |
| `art_20260918_9821af` | `coverage_calibration_ladder.md` | `bf82aa240795ebdbab1cdd6170c86552daa20433a6a363103be7c7e9b88bb55f` |
| `art_20260918_a408c2` | `coverage_calibration_v2.json` | `b4e7f8b0755a09561736ab7bfc39318980548a0ae0cfda7243e9de48a5b399dc` |
| `art_20260918_a73525` | `eth_full_mk_grid_a73525.json` | `522e25ff05b7ef84fe49bdc69ea6a2bd8fc50e56a7d26c7952c3f726adb89d7f` |
| `art_20260918_b5a5cd` | `eth_T2_T3_results_b5a5cd.json` | `cee50b40b7913279144c537cc632610a28c352606c0994bda5b2e62d72bc2d17` |
| `art_20260918_f27ba9` | `openset_floor_four_constructions.md` | `0ace3222da0fad188b9382dcbf97121c5513344db6f098672d29022e3cbe003b` |
| `art_20260918_fd1598` | `openset_floor_optimal_weighting.md` | `9d16e6ad93299c5ae3b9816f851b9830fd3a1dbb6db20e6ec442026c8884f644` |
| `art_20260919_17d7d3` | `track5_armA_block_bootstrap.json` | `b7bd97063a694c80d35147e1ada07a00abb573f01f1d142848936e14e62a32c8` |
| `art_20260919_b84113` | `track5_armB_sandwich.json` | `741b321095e0aab0e7ca3a3a62f7412757a33588b5eb37caeb5ab83e4a221965` |
| `art_20260919_fc043c` | `track5_armC_lobo.json` | `775ceede475a2f19f09ef398afe29632b02a4d8495b77270022716c013923c41` |
| `art_20260920_0e4cdb` | `track5_skewness_n5000.json` | `6558da3814befb13c9d86105b973b2f5e528d9c921fd125fdd800492db329ee9` |
| `art_20260922_764458` | `d181_balanced_accuracy_risk_interval.json` | `06c0e766f4a47280e4245ef41f72f89ade3fc6337be76a8e196074732de1e40d` |
| `art_20260922_f7853e` | `d181_joint_coverage_reaggregation.json` | `c05735901f4bb714c55446ee324afe354716bc0a8cd4de5df4120aae042fc218` |

## Exclusions

Superseded, retired, do-not-cite, stale plan, previous-reference, and `*.prev` files are excluded. `data_validation.json` from an older archive root is not included because it has no manifest entry.
